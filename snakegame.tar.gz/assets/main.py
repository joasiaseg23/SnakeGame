
import asyncio
import random
import pygame

# Game settings
WIDTH, HEIGHT = 600, 400
CELL = 20
FPS = 60
MOVE_DELAY = 120  # Snake moves every 120 milliseconds

# Colors
BLACK = (20, 20, 20)
GREEN = (0, 200, 0)
RED = (255, 60, 60)
WHITE = (255, 255, 255)

async def main():
    pygame.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Snake Game")
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 36)

    # Starting snake
    snake = [(200, 200), (180, 200), (160, 200)]
    direction = (CELL, 0)
    next_direction = direction
    score = 0
    game_over = False
    move_timer = 0

    def new_apple():
        # Place apple somewhere outside the snake
        empty = [
            (x, y)
            for x in range(0, WIDTH, CELL)
            for y in range(0, HEIGHT, CELL)
            if (x, y) not in snake
        ]
        return random.choice(empty) if empty else None

    apple = new_apple()
    running = True

    while running:
        dt = clock.tick(FPS)
        move_timer += dt

        # Handle keyboard input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                keys = {
                    pygame.K_UP: (0, -CELL),
                    pygame.K_DOWN: (0, CELL),
                    pygame.K_LEFT: (-CELL, 0),
                    pygame.K_RIGHT: (CELL, 0),
                    pygame.K_w: (0, -CELL),
                    pygame.K_s: (0, CELL),
                    pygame.K_a: (-CELL, 0),
                    pygame.K_d: (CELL, 0)
                }

                if event.key in keys:
                    new_dir = keys[event.key]

                    # Prevent reversing into yourself
                    if (new_dir[0] != -direction[0] or
                        new_dir[1] != -direction[1]):
                        next_direction = new_dir

                # Restart game
                if event.key == pygame.K_r and game_over:
                    snake = [(200, 200), (180, 200), (160, 200)]
                    direction = (CELL, 0)
                    next_direction = direction
                    score = 0
                    game_over = False
                    move_timer = 0
                    apple = new_apple()

        # Move snake at a fixed speed
        if not game_over and move_timer >= MOVE_DELAY:
            move_timer = 0
            direction = next_direction

            head_x, head_y = snake[0]
            dx, dy = direction
            new_head = (head_x + dx, head_y + dy)

            # Check wall collision
            hit_wall = (
                new_head[0] < 0 or
                new_head[0] >= WIDTH or
                new_head[1] < 0 or
                new_head[1] >= HEIGHT
            )

            eating = new_head == apple

            # Moving into the old tail is allowed
            body = snake if eating else snake[:-1]
            hit_body = new_head in body

            if hit_wall or hit_body:
                game_over = True
            else:
                snake.insert(0, new_head)

                if eating:
                    score += 1
                    apple = new_apple()
                    if apple is None:
                        game_over = True
                else:
                    snake.pop()

        # Draw background
        screen.fill(BLACK)

        # Draw apple
        if apple is not None:
            pygame.draw.circle(
                screen, RED,
                (apple[0] + CELL // 2,
                 apple[1] + CELL // 2),
                CELL // 2 - 2
            )

        # Draw snake
        for i, segment in enumerate(snake):
            color = (0, 255, 80) if i == 0 else GREEN
            pygame.draw.rect(
                screen, color,
                (segment[0], segment[1], CELL - 2, CELL - 2)
            )

        # Display score
        score_text = font.render(
            f"Score: {score}", True, WHITE
        )
        screen.blit(score_text, (10, 10))

        # Game over screen
        if game_over:
            message = "Game Over! Press R to Restart"
            if apple is None:
                message = "You Win! Press R to Restart"

            text = font.render(message, True, WHITE)
            rect = text.get_rect(
                center=(WIDTH // 2, HEIGHT // 2)
            )
            screen.blit(text, rect)

        pygame.display.flip()

        # Required for Pygbag browser compatibility
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
